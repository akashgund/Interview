package com.interview.lucidworks.Service;

public class UploadService {
}
